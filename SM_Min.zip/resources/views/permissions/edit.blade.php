@extends('layouts.app')

@section('content')

<div class="content-header-left col-12 mb-2 mt-1">
   <div class="row breadcrumbs-top">
      <div class="col-12">
         <h5 class="content-header-title float-left pr-1 mb-0">Permissions</h5>
         <div class="breadcrumb-wrapper col-12">
            <ol class="breadcrumb p-0 mb-0">
               <li class="breadcrumb-item ">
                  <a href="{{ route('permissions.index') }}"><i class="bx bx-home-alt"></i></a>
               </li>
               <li class="breadcrumb-item active">
                  Edit
               </li>
            </ol>
         </div>
      </div>
   </div>
</div>

<div class="content-body">


<!-- // Basic multiple Column Form section start -->
<div class="content-body">
   <!-- // Basic multiple Column Form section start -->
   <section id="multiple-column-form">
      <div class="row match-height">
         <div class="col-12">
            <div class="card">
               <div class="card-header">
                  <h4 class="card-title">Edit Permissions</h4>
                  <div class="heading-elements">
                      <ul class="list-inline mb-0">
                          <!-- Back Option -->
                          <a href="{{ route('permissions.index') }}" class="tooltip-light pl-0" data-toggle="tooltip"
                              data-placement="top" data-animation="true" data-original-title="Go back">
                              <button class="btn btn-icon rounded-circle btn-primary glow">
                              <i class="bx bx-left-arrow-circle"></i></button>
                          </a>
                          <!-- Back Option.End -->
                      </ul>
                  </div>
               </div>
               <div class="card-content">
                  <div class="card-body">
                     <form class="form" action="{{ route('permissions.update',[$permission->id]) }}" method="POST" id="permission-form">
                        <input type="hidden" name="_token" value="{{ csrf_token() }}">
                        <input type="hidden" name="_method" value="PUT"/>
                        <div class="form-body">
                           <div class="row">
                              <div class="col-md-6 col-12">
                                 <div class="form-label-group">
                                    <input type="text" id="first-name-column" class="form-control" placeholder="Name"
                                       name="name" value="{{ old('name', isset($permission) ? $permission->name: '') }}">
                                    <label for="first-name-column">Name</label>
                                    <span class="help-block">{{ $errors->first('name') }}</span>
                                 </div>
                              </div>
                              <div class="col-md-6 col-12">
                                 <ul class="list-unstyled mb-0">
                                    <p>Status</p>
                                    <li class="d-inline-block mr-2 mb-1">
                                       <fieldset>
                                          <div class="custom-control custom-radio">
                                             <input type="radio" class="custom-control-input" name="status" id="customRadio1" {{($permission->status == "Active") ? 'checked' : '' }} value="1">
                                             <label class="custom-control-label" for="customRadio1">Active</label>
                                          </div>
                                       </fieldset>
                                    </li>
                                    <li class="d-inline-block mr-2 mb-1">
                                       <fieldset>
                                          <div class="custom-control custom-radio">
                                             <input type="radio" class="custom-control-input" name="status" id="customRadio2" {{($permission->status == "Inactive") ? 'checked' : '' }} value="0">
                                             <label class="custom-control-label" for="customRadio2">Inactive</label>
                                          </div>
                                       </fieldset>
                                    </li>
                                 </ul>
                                 <span class="help-block">{{ $errors->first('status') }}</span>
                              </div>
                              <div class="col-md-12 col-12">
                                 <div class="form-label-group">
                                    <textarea class="form-control" id="basicTextarea" rows="3" placeholder="Description" name="description">{{old('description', isset($permission) ? $permission->description: '')}}</textarea>
                                    <label for="first-name-column">Description</label>
                                    <span class="help-block">{{$errors->first('description')}}</span>
                                 </div>
                              </div>
                              <div class="col-sm-12 d-flex justify-content-end">
                                 <button type="submit" class="btn btn-primary mr-1 mb-1">Submit</button>
                                 <button type="reset" class="btn btn-light-secondary mr-1 mb-1">Reset</button>
                              </div>
                           </div>
                        </div>
                     </form>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
   <!-- // Basic multiple Column Form section end -->
</div>
<!-- // Basic multiple Column Form section end -->
</div>




@endsection
