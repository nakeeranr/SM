<?php if($alertType == 'success' && !empty($alertMessage)): ?>
<div class="alert alert-success alert-dismissible mb-2" role="alert">
	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
	<span aria-hidden="true">&times;</span>
	</button>
	<div class="d-flex align-items-center">
		<i class="bx bx-like"></i>
		<span>
			<?php echo e($alertMessage); ?>

		</span>
	</div>
</div>
<?php elseif($alertType == 'error' && !empty($alertMessage)): ?>
<div class="alert alert-danger alert-dismissible mb-2" role="alert">
	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
	<span aria-hidden="true">&times;</span>
	</button>
	<div class="d-flex align-items-center">
		<i class="bx bx-error"></i>
		<span>
			<?php echo e($alertMessage); ?>

		</span>
	</div>
</div>
<?php elseif($alertType == 'warning' && !empty($alertMessage)): ?>
<div class="alert alert-warning alert-dismissible mb-2" role="alert">
	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
	<span aria-hidden="true">&times;</span>
	</button>
	<div class="d-flex align-items-center">
		<i class="bx bx-error-circle"></i>
		<span>
			<?php echo e($alertMessage); ?>

		</span>
	</div>
</div>
<?php endif; ?><?php /**PATH D:\Code\SM\resources\views/partials/_alerts.blade.php ENDPATH**/ ?>