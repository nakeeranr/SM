<?php
$required = !empty($is_required) ? 'required ': '';
?>

<?php if($type == 'text' && !empty($field_name) && !empty($pname)): ?>
<div class="form-group">
    <label for="<?php echo e($field_name); ?>"><?php echo e($pname); ?></label>
    <div class="controls">
        <input type="text" id="<?php echo e($field_name); ?>" class="form-control" <?php echo e($required); ?>

        <?php echo e($is_disabled ?? ''); ?> placeholder="<?php echo e($pname); ?>" name="<?php echo e($field_name); ?>" value="<?php echo e($val ?? old('$field_name')); ?>">
        <span class="help-block"><?php echo e($errors->first($field_name)); ?></span>
    </div>
</div>

<?php elseif($type == 'tel' && !empty($field_name) && !empty($pname) && !empty($maxLen)): ?>
<div class="form-group">
    <label for="<?php echo e($field_name); ?>"><?php echo e($pname); ?></label>
    <div class="controls">
        <input type="tel" id="<?php echo e($field_name); ?>" class="form-control" <?php echo e($required); ?> placeholder="<?php echo e($pname); ?>" name="<?php echo e($field_name); ?>" maxlength="<?php echo e($maxLen); ?>"
        onkeypress="return (event.charCode != 8 && event.charCode == 0 || (event.charCode >= 48 && event.charCode <= 57))" value="<?php echo e($val ?? old('$field_name')); ?>">
        <!-- <label for="<?php echo e($field_name); ?>"><?php echo e($pname); ?></label> -->
        <span class="help-block"><?php echo e($errors->first($field_name)); ?></span>
    </div>
</div>

<?php elseif($type == 'email' && !empty($field_name) && !empty($pname)): ?>
<label for="<?php echo e($field_name); ?>"><?php echo e($pname); ?></label>
<div class="form-label-group">
    <input type="email" id="<?php echo e($field_name); ?>" class="form-control <?php echo e($required); ?>" placeholder="<?php echo e($pname); ?>" name="<?php echo e($field_name); ?>" value="<?php echo e($val ?? old('$field_name')); ?>">
    <!-- <label for="<?php echo e($field_name); ?>"><?php echo e($pname); ?></label> -->
    <span class="help-block"><?php echo e($errors->first($field_name)); ?></span>
</div>

<?php elseif($type == 'datePicker' && !empty($field_name) && !empty($pname)): ?>
<label for="<?php echo e($field_name); ?>"><?php echo e($pname); ?></label>
<div class="form-label-group">
    <fieldset class="form-group position-relative has-icon-left">
        <input type="text" id="<?php echo e($field_name); ?>" class="form-control pickadate-months-year" <?php echo e($required); ?> placeholder="<?php echo e($pname); ?>" name="<?php echo e($field_name); ?>" value="<?php echo e($val ?? old('$field_name')); ?>">
        <div class="form-control-position">
            <i class='bx bx-calendar'></i>
        </div>
    </fieldset>
    <label for="<?php echo e($field_name); ?>"><?php echo e($pname); ?></label>
    <span class="help-block"><?php echo e($errors->first($field_name)); ?></span>
</div>

<?php elseif($type == 'radio' && !empty($field_name) && !empty($pname) && !empty($id)): ?>
<li class="d-inline-block mr-2 mb-1">
    <fieldset>
        <div class="radio radio-shadow">
              <input type="radio" id="<?php echo e($id); ?>" name="<?php echo e($field_name); ?>" <?php echo e($is_checked ?? ''); ?> value="<?php echo e($val); ?>">
              <label for="<?php echo e($id); ?>"><?php echo e($pname); ?></label>
        </div>
    </fieldset>
</li>

<?php elseif($type == 'button' && !empty($field_name) && !empty($pname) && !empty($class)): ?>
<button type="<?php echo e($field_name); ?>" class="<?php echo e($class); ?>"><?php echo e($pname); ?></button>

<?php elseif($type == 'select' && !empty($field_name) && !empty($pname) && !empty($options)): ?>
<label for="<?php echo e($field_name); ?>"><?php echo e($pname); ?></label>
<fieldset class="form-group">
    <select class="form-control <?php echo e(isset($is_multiple) ? 'select2' : ''); ?>" id="<?php echo e($field_name); ?>" <?php echo e($is_multiple ?? ''); ?> name="<?php echo e($field_name); ?><?php echo e(isset($is_multiple) ? '[]' : ''); ?>">
        <?php if(!isset($val) && !isset($is_multiple)): ?>
            <option selected disabled>Select <?php echo e($pname); ?></option>
        <?php endif; ?>
        
        <?php if(isset($val) && is_array($val)): ?>
            <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($key); ?>"   <?php echo e(in_array($key,$val) ? 'selected' : ''); ?> ><?php echo e($value); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($key); ?>"   <?php echo e(isset ($val) && ($val == $key) ? 'selected' : ''); ?> ><?php echo e($value); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

    </select>
</fieldset>

<?php elseif($type == 'textarea' && !empty($field_name) && !empty($pname) && !empty($length) && !empty($rows)): ?>
<label for="<?php echo e($field_name); ?>"><?php echo e($pname); ?></label>
<fieldset class="form-label-group mb-0">
    <textarea data-length="<?php echo e($length); ?>" class="form-control char-textarea" name="<?php echo e($field_name); ?>" id="textarea-counter" rows="<?php echo e($rows); ?>" placeholder="<?php echo e($pname); ?>"><?php echo e($val ?? old('$field_name')); ?></textarea>
    <!-- <label for="textarea-counter"><?php echo e($pname); ?></label> -->
</fieldset>
<small class="counter-value float-right"><span class="char-count">0</span> / <?php echo e($length); ?> </small>
<?php endif; ?><?php /**PATH D:\Code\SM\resources\views/partials/_formElements.blade.php ENDPATH**/ ?>