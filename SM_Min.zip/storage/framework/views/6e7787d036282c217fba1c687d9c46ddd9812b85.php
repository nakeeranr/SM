

<?php if(Route::currentRouteName() == 'home'): ?>

<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/pages/dashboard-analytics.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/pages/dashboard-analytics.css')); ?>">

 <!-- BEGIN: Vendor CSS-->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/css/charts/apexcharts.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/css/extensions/dragula.min.css')); ?>">
<!-- END: Vendor CSS-->

<?php elseif(Route::currentRouteName() == 'permissions.index'
|| Route::currentRouteName() == 'roles.index'
|| Route::currentRouteName() == 'roles.edit'
|| Route::currentRouteName() == 'admin-users.index'
|| Route::currentRouteName() == 'organizations.index'
): ?>

<!-- BEGIN: Vendor CSS-->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/css/tables/datatable/datatables.min.css')); ?>">
<!-- END: Vendor CSS-->

<?php elseif(Route::currentRouteName() == 'admin-users.create'
|| Route::currentRouteName() == 'admin-users.edit'
|| Route::currentRouteName() == 'organizations.create'
|| Route::currentRouteName() == 'organizations.edit'
): ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/css/pickers/pickadate/pickadate.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/plugins/forms/validation/form-validation.css')); ?>">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>

<?php elseif(Route::currentRouteName() == 'roles.create' 
): ?>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>


<?php endif; ?>
<?php /**PATH D:\Code\SM\resources\views/layouts/_pageHeader.blade.php ENDPATH**/ ?>